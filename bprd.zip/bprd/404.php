<html>
	<head>
		<title>Error 404 | SIAS</title>
	</head>
	<body>
		<center>
			<hr style="width: 450px;" width="650" />
			<h2 style="text-align: center;" align="center">
				<span style="font-size: 18px;">Maaf, Halaman Tidak di Temukan. Terima Kasih Banyak Atas Kunjungan Anda</span>
			</h2>
			<p style="text-align: center;" align="”center”">
				<span style="font-family: courier new,courier; font-size: 12px;">copyright <?php echo date("Y");?> <span style="font-size: 14px; font-family: arial,helvetica,sans-serif;">&copy;</span> &nbsp;<a href="#" target="_blank">SIAS</a></span>
			</p>
		</center>
	</body>
</html>